/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class forcestart
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*    */   {
/* 17 */     Player player = (Player)sender;
/* 18 */     player.sendMessage(ChatColor.GREEN + "The Game is being force started!");
/*    */     
/* 20 */     String gamestate = "Starting";
/* 21 */     boolean running = true;
/* 22 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\forcestart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */