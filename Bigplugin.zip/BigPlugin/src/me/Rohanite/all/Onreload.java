/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*    */ 
/*    */ public class Onreload implements org.bukkit.event.Listener
/*    */ {
/*    */   @org.bukkit.event.EventHandler
/*    */   public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event)
/*    */   {
/* 10 */     if (event.getMessage().equals("/rl")) {
/* 11 */       event.setCancelled(true);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\Onreload.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */