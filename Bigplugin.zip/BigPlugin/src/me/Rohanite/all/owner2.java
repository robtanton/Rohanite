/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ 
/*    */ public class owner2
/*    */   implements CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/* 14 */   public owner2(Main plugin) { this.pl = plugin; }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 17 */     if (!(sender instanceof org.bukkit.entity.Player)) {
/* 18 */       String tp = args[0];
/* 19 */       this.pl.getConfig().set("owner2", tp);
/*    */     }
/*    */     else {
/* 22 */       sender.sendMessage(ChatColor.RED + "Sorry but you cant use this command!");
/*    */     }
/* 24 */     return false;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\owner2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */