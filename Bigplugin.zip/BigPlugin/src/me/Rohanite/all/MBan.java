/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.BanList;
/*    */ import org.bukkit.BanList.Type;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBan
/*    */   implements CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public MBan(Main plugin)
/*    */   {
/* 22 */     this.pl = plugin;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args)
/*    */   {
/* 27 */     Bukkit.getBanList(BanList.Type.NAME).addBan(args[0], ChatColor.DARK_RED + "You have been banned from PvPMC                                                                                                                                                                               Reason:" + args[1], null, sender.getName());
/* 28 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\MBan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */