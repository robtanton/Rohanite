package me.Rohanite.all.api;

import org.bukkit.entity.Player;

import me.Rohanite.all.Main;

public class SLAPI{
	  private static Main plugin = EconManager.getPlugin();
	  
	  public static void saveBalances()
	  {
	    for (String p : EconManager.getBalanceMap().keySet()) {
	      plugin.getConfig().set("balance" + p, EconManager.getBalanceMap().get(p));
	    }
	    plugin.saveConfig();
	  }
	  
	  public static void loadBalances()
	  {
	    if (!plugin.getConfig().contains("balance")) {
	      return;
	    }
	    for (String s : plugin.getConfig().getConfigurationSection("balance").getKeys(false)) {
	      EconManager.setBalance(s, (int) plugin.getConfig().getDouble("balance" + s));
	    }
	  }
}
