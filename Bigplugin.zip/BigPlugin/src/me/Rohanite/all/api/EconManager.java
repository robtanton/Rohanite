/*    */ package me.Rohanite.all.api;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.UUID;

import org.bukkit.entity.Player;

import me.Rohanite.all.Main;
/*    */ 
/*    */ 
/*    */ public class EconManager
/*    */ {
	 private static Main plugin;
	  
	  public EconManager(Main instance)
	  {
	    plugin = instance;
	  }
	  
	  public static HashMap<String, Integer> bal = new HashMap();
	  
	  public static void setBalance(String player, Integer amount)
	  {
	    bal.put(player, Integer.valueOf(amount));
	  }
	  
	  public static Integer getBalance(String player)
	  {
	    return bal.get(player);
	  }
	  
	  public static boolean hasAccount(String player)
	  {
	    return bal.containsKey(player);
	  }
	  
	  public static boolean createAccount(String player)
	  {
	    return bal.containsKey(player);
	  }
	  
	  public static HashMap<String, Integer> getBalanceMap()
	  {
	    return bal;
	  }
	  
	  public static Main getPlugin()
	  {
	    return plugin;
	  }
}

