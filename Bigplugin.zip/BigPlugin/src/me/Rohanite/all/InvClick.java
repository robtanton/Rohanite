/*     */ package me.Rohanite.all;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.Sign;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.block.SignChangeEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.EntityEquipment;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.permissions.PermissionAttachment;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;

import com.turqmelon.MelonEco.utils.Account;
import com.turqmelon.MelonEco.utils.AccountManager;
import com.turqmelon.MelonEco.utils.Currency;
/*     */ 
/*     */ public class InvClick implements Listener
/*     */ {
/*     */   private Main pl;
/*     */   
/*     */   public InvClick(Main plugin)
/*     */   {
/*  33 */     this.pl = plugin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @EventHandler
/*     */   public void onSignChange(SignChangeEvent sign)
/*     */   {
/*  43 */     Player player = sign.getPlayer();
/*     */     
/*     */ 
/*  46 */     if (sign.getLine(0).equalsIgnoreCase("[kit]"))
/*     */     {
/*     */ 
/*  49 */       sign.setLine(0, "[kit]");
/*     */       
/*     */ 
/*  52 */       sign.getLine(1);
/*     */       
/*     */ 
/*  55 */       if (sign.getLine(1).equalsIgnoreCase("Archer"))
/*     */       {
/*     */ 
/*  58 */         player.sendMessage(ChatColor.YELLOW + "kit Archer Sign Has Been Created!");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*  64 */       else if (sign.getLine(1).equalsIgnoreCase("Tank"))
/*     */       {
/*     */ 
/*  67 */         player.sendMessage(ChatColor.YELLOW + "kit Tank Sign Has Been Created!");
/*     */ 
/*     */ 
/*     */       }
/*  71 */       else if (sign.getLine(1).equalsIgnoreCase("Starter"))
/*     */       {
/*     */ 
/*  74 */         player.sendMessage(ChatColor.YELLOW + "kit Starter Sign Has Been Created!");
/*     */ 
/*     */ 
/*     */       }
/*  78 */       else if (sign.getLine(1).equalsIgnoreCase("Ninja"))
/*     */       {
/*     */ 
/*  81 */         player.sendMessage(ChatColor.YELLOW + "kit Ninja Sign Has Been Created!");
/*     */       }
/*     */     }
/*     */   
/*     */   
/*     */ 

}

/*     */ 
/*     */ 
/*     */   @EventHandler
/*     */   public void invClick(PlayerInteractEvent e)
/*     */   {
/*  94 */     Player p = e.getPlayer();
/*     */     
/*  96 */     if(e.getAction() == Action.RIGHT_CLICK_BLOCK) {
	  if(e.getClickedBlock().getType() == Material.SIGN || e.getClickedBlock().getType() == Material.SIGN_POST || e.getClickedBlock().getType() == Material.WALL_SIGN) {
		    Sign sign = (Sign) e.getClickedBlock().getState();
		    if(sign.getLine(0).equalsIgnoreCase("[kit]")){
		    if(sign.getLine(1).equalsIgnoreCase("Tank")) {
		    	for (PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
		    	if(p.hasPermission("kpvp.two")){
p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 100000000, 2));
p.getInventory().clear();

 p.getInventory().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
 p.getInventory().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
 p.getInventory().setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
 p.getInventory().setBoots(new ItemStack(Material.DIAMOND_BOOTS));
 p.getInventory().setItem(0, new ItemStack(Material.IRON_SWORD));
		    	} else
		    	    p.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
		    /*    */     }
		    }
		    
		    if(sign.getLine(1).equalsIgnoreCase("Warrior")) {
		    	for (PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
		    	p.getInventory().clear();

 p.getInventory().setHelmet(new ItemStack(Material.IRON_HELMET));
 p.getInventory().setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
 p.getInventory().setLeggings(new ItemStack(Material.IRON_LEGGINGS));
 p.getInventory().setBoots(new ItemStack(Material.IRON_BOOTS));
 p.getInventory().setItem(0, new ItemStack(Material.DIAMOND_SWORD));
 p.getInventory().setItem(1, new ItemStack(Material.GOLDEN_APPLE));
		    }
		    if(sign.getLine(1).equalsIgnoreCase("Buddur")) {
		    	for (PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());

		    	ItemStack gsword = new ItemStack(Material.GOLD_SWORD, 1);
		    	gsword.addEnchantment(Enchantment.DAMAGE_ALL, 2);
		    	gsword.addEnchantment(Enchantment.KNOCKBACK, 2);
		    	gsword.addEnchantment(Enchantment.DURABILITY, 3);
		    	ItemStack ghelm = new ItemStack(Material.GOLD_HELMET, 1);
		    	ghelm.addEnchantment(Enchantment.DURABILITY, 3);
		    	ItemStack gchest = new ItemStack(Material.GOLD_CHESTPLATE, 1);
		    	gchest.addEnchantment(Enchantment.DURABILITY, 3);
		    	ItemStack gleg = new ItemStack(Material.GOLD_LEGGINGS, 1);
		    	gleg.addEnchantment(Enchantment.DURABILITY, 3);
		    	ItemStack gboot = new ItemStack(Material.GOLD_BOOTS, 1);
		    	gboot.addEnchantment(Enchantment.DURABILITY, 3);
 p.getInventory().setHelmet(ghelm);
 p.getInventory().setChestplate(gchest);
 p.getInventory().setLeggings(gleg);
 p.getInventory().setBoots(gboot);
 p.getInventory().setItem(0, gsword);
 p.getInventory().setItem(1, new ItemStack(Material.GOLDEN_APPLE));
		    }
		    if(sign.getLine(1).equalsIgnoreCase("Archer")) {
		    	for (PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
		    	p.getInventory().clear();

		    	ItemStack bow = new ItemStack(Material.BOW, 1);
		    	bow.addEnchantment(Enchantment.ARROW_KNOCKBACK, 2);
		    	bow.addEnchantment(Enchantment.ARROW_INFINITE, 1);
		    	bow.addEnchantment(Enchantment.ARROW_DAMAGE, 3);
		    	ItemStack specarrow = new ItemStack(Material.SPECTRAL_ARROW, 200);
		    	

 p.getInventory().setHelmet(new ItemStack(Material.LEATHER_HELMET));
 p.getInventory().setChestplate(new ItemStack(Material.LEATHER_CHESTPLATE));
 p.getInventory().setLeggings(new ItemStack(Material.LEATHER_LEGGINGS));
 p.getInventory().setBoots(new ItemStack(Material.LEATHER_BOOTS));
 p.getInventory().setItem(0, bow);
 p.getInventory().setItem(1, new ItemStack(Material.WOOD_SWORD));
 p.getInventory().setItem(2, specarrow);
		    }
		    if(sign.getLine(1).equalsIgnoreCase("Demon")) {
		    	for (PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
		    	p.getInventory().clear();
		    	
		    	p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 100000000, 1));

		    	ItemStack lhelm = new ItemStack(Material.LEATHER_HELMET, 1);
		    	LeatherArmorMeta lmh = (LeatherArmorMeta) lhelm.getItemMeta();
		    	lmh.setColor(Color.RED);
		    	lhelm.setItemMeta(lmh);
		    	ItemStack lchest = new ItemStack(Material.LEATHER_CHESTPLATE, 1);
		    	LeatherArmorMeta lmc = (LeatherArmorMeta) lchest.getItemMeta();
		    	lmc.setColor(Color.RED);
		    	lchest.setItemMeta(lmc);
		    	ItemStack leg = new ItemStack(Material.LEATHER_LEGGINGS, 1);
		    	LeatherArmorMeta lml = (LeatherArmorMeta) leg.getItemMeta();
		    	lml.setColor(Color.RED);
		    	leg.setItemMeta(lml);
		    	ItemStack lboot = new ItemStack(Material.LEATHER_BOOTS, 1);
		    	LeatherArmorMeta lmb = (LeatherArmorMeta) lboot.getItemMeta();
		    	lmb.setColor(Color.RED);
		    	lboot.setItemMeta(lmb);
		    	ItemStack blaze = new ItemStack(Material.WOOD_SWORD, 1);
		        blaze.addEnchantment(Enchantment.FIRE_ASPECT, 2);
		        blaze.addEnchantment(Enchantment.DAMAGE_ALL, 3);
	
	
		    	

 p.getInventory().setHelmet(lhelm);
 p.getInventory().setChestplate(lchest);
 p.getInventory().setLeggings(leg);
 p.getInventory().setBoots(lboot);
 p.getInventory().setItem(0, blaze);


		    }
		    if(sign.getLine(1).equalsIgnoreCase("Ninja")) {
		    	for (PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
		    	p.getInventory().clear();
		    	
		    	p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100000000, 2));

		    	ItemStack lhelm = new ItemStack(Material.LEATHER_HELMET, 1);
		    	LeatherArmorMeta lmh = (LeatherArmorMeta) lhelm.getItemMeta();
		    	lmh.setColor(Color.BLACK);
		    	lhelm.setItemMeta(lmh);
		    	ItemStack lchest = new ItemStack(Material.LEATHER_CHESTPLATE, 1);
		    	LeatherArmorMeta lmc = (LeatherArmorMeta) lchest.getItemMeta();
		    	lmc.setColor(Color.BLACK);
		    	lchest.setItemMeta(lmc);
		    	ItemStack leg = new ItemStack(Material.LEATHER_LEGGINGS, 1);
		    	LeatherArmorMeta lml = (LeatherArmorMeta) leg.getItemMeta();
		    	lml.setColor(Color.BLACK);
		    	leg.setItemMeta(lml);
		    	ItemStack lboot = new ItemStack(Material.LEATHER_BOOTS, 1);
		    	LeatherArmorMeta lmb = (LeatherArmorMeta) lboot.getItemMeta();
		    	lmb.setColor(Color.BLACK);
		    	lboot.setItemMeta(lmb);
		    	ItemStack Sword = new ItemStack(Material.WOOD_SWORD, 1);
		        Sword.addEnchantment(Enchantment.FIRE_ASPECT, 1);
		        Sword.addEnchantment(Enchantment.DAMAGE_ALL, 3);
	
	
		    	

 p.getInventory().setHelmet(lhelm);
 p.getInventory().setChestplate(lchest);
 p.getInventory().setLeggings(leg);
 p.getInventory().setBoots(lboot);
 p.getInventory().setItem(0, Sword);


		    }
		    if(sign.getLine(1).equalsIgnoreCase("Gymnist")) {
		    	for (PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
		    	p.getInventory().clear();
		    	p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 100000000, 2));
		    	p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100000000, 2));

		    	ItemStack lhelm = new ItemStack(Material.LEATHER_HELMET, 1);
		    	LeatherArmorMeta lmh = (LeatherArmorMeta) lhelm.getItemMeta();
		    	lmh.setColor(Color.YELLOW);
		    	lhelm.setItemMeta(lmh);
		    	ItemStack lchest = new ItemStack(Material.LEATHER_CHESTPLATE, 1);
		    	LeatherArmorMeta lmc = (LeatherArmorMeta) lchest.getItemMeta();
		    	lmc.setColor(Color.GREEN);
		    	lchest.setItemMeta(lmc);
		    	ItemStack leg = new ItemStack(Material.LEATHER_LEGGINGS, 1);
		    	LeatherArmorMeta lml = (LeatherArmorMeta) leg.getItemMeta();
		    	lml.setColor(Color.YELLOW);
		    	leg.setItemMeta(lml);
		    	ItemStack lboot = new ItemStack(Material.LEATHER_BOOTS, 1);
		    	LeatherArmorMeta lmb = (LeatherArmorMeta) lboot.getItemMeta();
		    	lmb.setColor(Color.GREEN);
		    	lboot.setItemMeta(lmb);
		    	ItemStack blaze = new ItemStack(Material.WOOD_SWORD, 1);
		        blaze.addEnchantment(Enchantment.KNOCKBACK, 2);
		        blaze.addEnchantment(Enchantment.DAMAGE_ALL, 5);
	
	
		    	

 p.getInventory().setHelmet(lhelm);
 p.getInventory().setChestplate(lchest);
 p.getInventory().setLeggings(leg);
 p.getInventory().setBoots(lboot);
 p.getInventory().setItem(0, blaze);


		    }
		    if(sign.getLine(1).equalsIgnoreCase("Enhanced")) {
		    	for (PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
		    	if(p.hasPermission("kpvp.three")){
p.getInventory().clear();

ItemStack gapple = new ItemStack(Material.getMaterial(322), 1, (short) 1);

 p.getInventory().setHelmet(new ItemStack(Material.GOLD_HELMET));
 p.getInventory().setChestplate(new ItemStack(Material.LEATHER_CHESTPLATE));
 p.getInventory().setLeggings(new ItemStack(Material.LEATHER_LEGGINGS));
 p.getInventory().setBoots(new ItemStack(Material.GOLD_BOOTS));
 p.getInventory().setItem(0, new ItemStack(Material.STONE_SWORD));
 p.getInventory().setItem(1, gapple);
		    	} else
		    	    p.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
		    /*    */     }
		    if(sign.getLine(1).equalsIgnoreCase("Gladiator")) {
		    	for (PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
		    	if(p.hasPermission("kpvp.three")){
p.getInventory().clear();

 p.getInventory().setHelmet(new ItemStack(Material.IRON_HELMET));
 p.getInventory().setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
 p.getInventory().setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
 p.getInventory().setBoots(new ItemStack(Material.CHAINMAIL_BOOTS));
 p.getInventory().setItem(0, new ItemStack(Material.DIAMOND_AXE));
 p.getInventory().setItem(1, new ItemStack(Material.GOLDEN_APPLE));
 p.getInventory().setItemInOffHand(new ItemStack(Material.SHIELD));
		    	} else
		    	    p.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
		    /*    */     }
		    
		    
		    
		    if(sign.getLine(0).equalsIgnoreCase("[buy]")) {
		    	if(sign.getLine(1).equalsIgnoreCase("Tier 2")) {
		    		if(!(p.hasPermission("kpvp.two"))){
		    		Account account = AccountManager.getAccount(p.getName());
		    				Currency currency = AccountManager.getDefaultCurrency();
		    				double amount = 2000;
		    				if (account.withdraw(currency, amount)){
		    				  // Withdraw was successfu
		    					 p.sendMessage(ChatColor.GREEN + "Purchase Succesful!");
		    					 //("kpvp.kits.tank");
		    					 PermissionAttachment attachment = p.addAttachment(pl);
		    					 pl.perms.put(p.getName(), attachment);
		    					 
		    					 PermissionAttachment pperms = pl.perms.get(p.getName());
		    					 pperms.setPermission("kpvp.two", true);
		    			}

		    				else{
		    				  p.sendMessage(ChatColor.RED + "You have insufficient funds!");
		    				}
		    		    	if(sign.getLine(1).equalsIgnoreCase("Tier 3")) {
		    		    		if(!(p.hasPermission("kpvp.three"))){
		    		    				Currency currency1 = AccountManager.getDefaultCurrency();
		    		    				double amount1 = 000;
		    		    				if (account.withdraw(currency1, amount1)){
		    		    				  // Withdraw was successfu
		    		    					 p.sendMessage(ChatColor.GREEN + "Purchase Succesful!");
		    		    					 //("kpvp.kits.tank");
		    		    					 PermissionAttachment attachment = p.addAttachment(pl);
		    		    					 pl.perms.put(p.getName(), attachment);
		    		    					 
		    		    					 PermissionAttachment pperms = pl.perms.get(p.getName());
		    		    					 pperms.setPermission("kpvp.three", true);
		    		    			}

		    		    				else{
		    		    				  p.sendMessage(ChatColor.RED + "You have insufficient funds!");
		    		    				}
		    			
		    	}
		    	}
		    	}
		    	
		    }
	

		    
	  }
/*     */   }
}
}
}


/*     */ 


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\InvClick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */