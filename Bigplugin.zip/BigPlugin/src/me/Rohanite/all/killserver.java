/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class killserver implements org.bukkit.command.CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public killserver(Main plugin)
/*    */   {
/* 14 */     this.pl = plugin;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*    */   {
/* 19 */     if (sender.hasPermission("bp.server.killserver")) {
/* 20 */       Server s = this.pl.getServer();
/* 21 */       s.broadcastMessage(ChatColor.GREEN + "THE SERVER IS SHUTTING DOWN IN " + ChatColor.RED + "60" + ChatColor.GREEN + " SECONDS!");
/*    */       
/* 23 */       org.bukkit.Bukkit.getScheduler().scheduleSyncDelayedTask(this.pl, new Runnable() {
/*    */         public void run() {
/* 25 */           Server s = killserver.this.pl.getServer();
/*    */           
/* 27 */           s.shutdown();
/*    */         }
/* 29 */       }, 1800L);
/*    */     } else {
/* 31 */       sender.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
/*    */     }
/*    */     
/*    */ 
/* 35 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\killserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */