/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class owner5 implements CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public owner5(Main plugin)
/*    */   {
/* 15 */     this.pl = plugin;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 19 */     if (!(sender instanceof Player)) {
/* 20 */       String tp = args[0];
/* 21 */       this.pl.getConfig().set("owner5", tp);
/*    */     }
/*    */     
/* 24 */     return false;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\owner5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */