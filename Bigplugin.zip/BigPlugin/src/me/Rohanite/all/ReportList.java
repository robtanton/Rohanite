/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class ReportList implements org.bukkit.command.CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public ReportList(Main plugin)
/*    */   {
/* 12 */     this.pl = plugin;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*    */   {
/* 17 */     if (sender.hasPermission("bp.cheat.reportlist")) {
/* 18 */       Object list = this.pl.getConfig().get("Report List");
/* 19 */       sender.sendMessage((String)list);
/*    */     } else {
/* 21 */       sender.sendMessage(org.bukkit.ChatColor.RED + "You do not have permission to do this command!");
/*    */     }
/* 23 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\ReportList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */