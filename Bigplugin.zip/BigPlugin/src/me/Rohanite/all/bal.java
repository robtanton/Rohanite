/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import me.Rohanite.all.api.EconManager;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class bal
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
/*    */   {
/* 15 */     Player p = (Player)sender;
/* 16 */    int bal = EconManager.getBalance(p.getName());
/* 17 */     sender.sendMessage(ChatColor.GREEN + "Balance: " + ChatColor.AQUA + "$" + bal);
/*    */     
/* 19 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\bal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */