/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.weather.WeatherChangeEvent;
/*    */ 
/*    */ public class RainEvent implements Listener
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public RainEvent(Main plugin)
/*    */   {
/* 13 */     this.pl = plugin;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onRain(WeatherChangeEvent e) {
/* 18 */     e.setCancelled(true);
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\RainEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */