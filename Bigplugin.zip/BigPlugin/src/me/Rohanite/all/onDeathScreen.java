/*     */ package me.Rohanite.all;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.GameMode;
import org.bukkit.Location;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class onDeathScreen
/*     */   implements Listener
/*     */ {
private static final Location Deathloc = null;
/*     */   EntityDamageEvent.DamageCause cause;
/*     */   private Main pl;
/*  37 */   String PlayerMode = "PLAYER";
/*     */   
/*  39 */   public onDeathScreen(Main plugin) { this.pl = plugin; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @EventHandler
/*     */   public void DeathEvent(PlayerDeathEvent e)
/*     */   {
	Player p = e.getEntity().getPlayer();
	final Location loc = p.getLocation();
/*  72 */     if (this.cause == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
/*  73 */       String killer = e.getEntity().getKiller().getDisplayName();
/*  74 */       String deadp = e.getEntity().getDisplayName();
/*  75 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " was ruthlessely murdered by " + ChatColor.DARK_BLUE + killer);
/*     */     }
/*  77 */     if (this.cause == EntityDamageEvent.DamageCause.VOID) {
/*  78 */       String deadp = e.getEntity().getDisplayName();
/*  79 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " forgot that there was a void up ahead!");
/*     */     }
/*  81 */     if (this.cause == EntityDamageEvent.DamageCause.FIRE_TICK) {
/*  82 */       String deadp = e.getEntity().getDisplayName();
/*  83 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " got burned");
/*     */     }
/*  85 */     if (this.cause == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
/*  86 */       String deadp = e.getEntity().getDisplayName();
/*  87 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " forgot explosives were dangerous!");
/*     */     }
/*  89 */     if (this.cause == EntityDamageEvent.DamageCause.PROJECTILE) {
/*  90 */       String killer = e.getEntity().getKiller().getDisplayName();
/*  91 */       String deadp = e.getEntity().getDisplayName();
/*  92 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " took an arrow to the head thanks to " + ChatColor.DARK_BLUE + killer);
/*     */     }
/*  94 */     if (this.cause == EntityDamageEvent.DamageCause.DROWNING)
/*     */     {
/*  96 */       String deadp = e.getEntity().getDisplayName();
/*  97 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " thought they were a fish!");
/*     */     }
/*  99 */     if (this.cause == EntityDamageEvent.DamageCause.WITHER) {
/* 100 */       String deadp = e.getEntity().getDisplayName();
/* 101 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " sadly withered away!");
/*     */     }
/* 103 */     if (this.cause == EntityDamageEvent.DamageCause.FALL) {
/* 104 */       String deadp = e.getEntity().getDisplayName();
/* 105 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " thought they could fly!");
/*     */     }
/* 107 */     if (this.cause == EntityDamageEvent.DamageCause.THORNS) {
/* 108 */       Player killer = e.getEntity().getKiller();
/* 109 */       String deadp = e.getEntity().getDisplayName();
/* 110 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " was ruthlessely murdered by " + ChatColor.DARK_BLUE + killer);
/*     */     }
/* 112 */     if (this.cause == EntityDamageEvent.DamageCause.LAVA) {
/* 113 */       String deadp = e.getEntity().getDisplayName();
/* 114 */       e.setDeathMessage(ChatColor.DARK_BLUE + deadp + ChatColor.DARK_RED + " got lava and water mixed up!");
/*     */     }
/* 116 */     
/*     */     
/* 118 */     p.setGameMode(GameMode.ADVENTURE);
/*     */     
/*     */ 
/* 121 */     p.getInventory().clear();
/* 122 */     p.getInventory().setHelmet(null);
/*     */     
/*     */ 
/* 125 */     p.getInventory().setChestplate(null);
/*     */     
/*     */ 
/* 128 */     p.getInventory().setLeggings(null);
/*     */     
/*     */ 
/* 131 */     p.getInventory().setBoots(null);

/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */  
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemStack nameItem(ItemStack item, String name)
/*     */   {
/* 149 */     ItemMeta meta = item.getItemMeta();
/* 150 */     List<String> lore = new ArrayList();
/* 151 */     lore.add(ChatColor.GOLD + "Takes you to the hub!");
/*     */     
/* 153 */     meta.setDisplayName(name);
/* 154 */     meta.setLore(lore);
/* 155 */     item.setItemMeta(meta);
/* 156 */     return item;
/*     */   }

/*     */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\onDeathScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */