/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.player.PlayerKickEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ public class PlayerQuit implements org.bukkit.event.Listener
/*    */ {
/*    */   private Main plugin;
/*    */   
/*    */   public PlayerQuit(Main pl)
/*    */   {
/* 17 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerQuit(PlayerQuitEvent e) {
/* 22 */     String QM = "";
/* 23 */     Player localPlayer; for (Iterator localIterator = Bukkit.getOnlinePlayers().iterator(); localIterator.hasNext(); localPlayer = (Player)localIterator.next()) {}
/*    */     
/*    */ 
/* 26 */     e.setQuitMessage("");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerKick(PlayerKickEvent e) { Player localPlayer;
/* 31 */     for (Iterator localIterator = Bukkit.getOnlinePlayers().iterator(); localIterator.hasNext(); localPlayer = (Player)localIterator.next()) {}
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\PlayerQuit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */