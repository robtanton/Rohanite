/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Onchat
/*    */   implements Listener
/*    */ {
/*    */   private Main plugin;
/*    */   private Server s;
/*    */   
/*    */   public Onchat(Main pl)
/*    */   {
/* 24 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */ 
/*    */   @EventHandler
/*    */   public void onChat(AsyncPlayerChatEvent event)
/*    */   {
/* 31 */     Player player = event.getPlayer();
/*    */     
/* 33 */     String pname = player.getName();
/*    */     
/*    */ 
/* 36 */     String playername = player.getName() + ": " + ChatColor.GOLD + event.getMessage();
/*    */      String playername1 = player.getName() + ": " + ChatColor.DARK_GRAY + event.getMessage();
/*    */     
/*    */ 
String owner2 = "Boston54";
String owner1 = "Rohanite";
/*    */ 
/* 43 */     if (player.getName() == "Rohanite") {
/* 44 */       event.setFormat(ChatColor.DARK_RED + ""+ ChatColor.MAGIC + "XX" + ChatColor.RESET + ChatColor.DARK_RED + "Owner" + ChatColor.MAGIC + "XX" + ChatColor.RESET + ChatColor.DARK_RED + playername);
/*    */     } else if (pname == owner2) {
	/* 44 */       event.setFormat(ChatColor.DARK_RED + ""+ ChatColor.MAGIC + "XX" + ChatColor.RESET + ChatColor.DARK_RED + "Owner" + ChatColor.MAGIC + "XX" + ChatColor.RESET + ChatColor.DARK_RED + playername);
/* 46 */ } else{
	 event.setFormat(ChatColor.GREEN + "Default " + ChatColor.RESET + ChatColor.GRAY + playername1);
}
/*    */     }
/*    */   
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\Onchat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */