/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class BanEvent extends Event
/*    */ {
/*    */   Player p;
/*    */   Type t;
/*    */   
/*    */   public BanEvent(Player p, Type t)
/*    */   {
/* 14 */     this.p = p;
/* 15 */     this.t = t;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 19 */     return this.p;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 23 */     return this.t;
/*    */   }
/*    */   
/* 26 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   public HandlerList getHandlers() {
/* 29 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 33 */     return handlers;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\BanEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */