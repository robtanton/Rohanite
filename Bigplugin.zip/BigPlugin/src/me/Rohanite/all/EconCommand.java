package me.Rohanite.all;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import me.Rohanite.all.api.EconManager;

public class EconCommand implements CommandExecutor
{
	  public boolean onCommand(CommandSender cs, Command command, String s, String[] args)
	  {
	    if (args.length != 3)
	    {
	      cs.sendMessage(ChatColor.RED + "SmallEconomy Information!");
	      cs.sendMessage(ChatColor.GOLD + "Author: KiNg,NizarZa123");
	      cs.sendMessage(ChatColor.GOLD + "Version: 1.9.9");
	      cs.sendMessage(ChatColor.GOLD + "Author Upload file and coding Plugin: NizarZa123");
	      cs.sendMessage(ChatColor.GOLD + "What Doing this plugin?: This plugin you can create account with money, add money , remove money");
	      cs.sendMessage(ChatColor.GOLD + "Command Create Account: /econ set <player>");
	      cs.sendMessage(ChatColor.GOLD + "Commands: /econ <add/remove> <player> <amount>");
	      cs.sendMessage(ChatColor.GOLD + "WebSite: http://www.smalleconomy.weebly.com");
	      
	      return false;
	    }
	    if (args[0].equalsIgnoreCase("add"))
	    {
	      if (!EconManager.hasAccount(args[1]))
	      {
	        cs.sendMessage(ChatColor.RED + "Error: Player does not have an account");
	        
	        return true;
	      }
	      int amount = 0;
	      try
	      {
	        amount = Integer.parseInt(args[2]);
	      }
	      catch (Exception e)
	      {
	        cs.sendMessage(ChatColor.RED + "You gotta enter in a number bro");
	        
	        return true;
	      }
	      EconManager.setBalance(args[1], EconManager.getBalance(args[1]).intValue() + amount);
	    }
	    else if (args[0].equalsIgnoreCase("remove"))
	    {
	      if (!EconManager.hasAccount(args[1]))
	      {
	        cs.sendMessage(ChatColor.RED + "Error: Player does not have an account");
	        return true;
	      }
	      double amount = 0.0D;
	      try
	      {
	        amount = Integer.parseInt(args[2]);
	      }
	      catch (Exception e)
	      {
	        cs.sendMessage(ChatColor.RED + "You gotta enter in a number bro");
	        return true;
	      }
	      EconManager.setBalance(args[1], (int) (EconManager.getBalance(args[1]).doubleValue() - amount));
	    }
	    else if (args[0].equalsIgnoreCase("set"))
	    {
	      if (!EconManager.hasAccount(args[1]))
	      {
	        cs.sendMessage(ChatColor.RED + "Error: Player does not have an account");
	        return true;
	      }
	      Integer amount = 0;
	      try
	      {
	        amount = Integer.parseInt(args[2]);
	      }
	      catch (Exception e)
	      {
	        cs.sendMessage(ChatColor.RED + "You gotta enter in a number bro");
	        return true;
	      }
	      EconManager.setBalance(args[1], amount);
	    }
	    else
	    {
	      cs.sendMessage(ChatColor.RED + "Incorrect argument");
	    }
	    return true;
	  }
	

}
