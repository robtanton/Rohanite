/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ 
/*    */ 
/*    */ public class owner4
/*    */   implements CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/* 15 */   public owner4(Main plugin) { this.pl = plugin; }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 18 */     if (!(sender instanceof org.bukkit.entity.Player)) {
/* 19 */       String tp = args[0];
/* 20 */       this.pl.getConfig().set("owner4", tp);
/*    */     }
/*    */     else {
/* 23 */       sender.sendMessage(ChatColor.RED + "Sorry but you cant use this command!");
/*    */     }
/* 25 */     return false;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\owner4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */