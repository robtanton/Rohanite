/*    */ package me.Rohanite.all;
import java.util.Collection;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Cow;
/*    */ 
/*    */ import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.entity.Villager;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import net.minecraft.server.v1_10_R1.NPC;

/*    */ 
/*    */ public class AntiCheat implements Listener
/*    */ {
	/*    */   private Main plugin;
	/*    */   
	/*    */   public AntiCheat(Main pl)
	/*    */   {
	/* 24 */     this.plugin = pl;
	/*    */   }

	@SuppressWarnings("deprecation")
	private void spawnEntity(Location location, String name, Class someEntity) {
        Entity entity = location.getWorld().spawn(location, someEntity);
        entity.setCustomName("ACheat");
        entity.setCustomNameVisible(true);
        if (entity instanceof Ageable) {
            Ageable ageable = (Ageable) entity;
            ageable.setBaby();
            ageable.setAgeLock(true);
        }

        if (entity instanceof LivingEntity) {
            ((LivingEntity) entity).getEquipment().setItemInHand(new ItemStack(Material.CACTUS));
        }
    }
	@EventHandler
	public void onEntityDeath(EntityDeathEvent event) {
	Entity entity = event.getEntity().getKiller();
	EntityType sheep = event.getEntityType();
	entity.getWorld().spawnEntity(entity.getLocation(), sheep);
	}


/*    */   @EventHandler
/*    */   public void DamageEvent(EntityDamageEvent e)   {


/*    */   }
/*    */   @EventHandler
/*    */   public void Move(PlayerMoveEvent e)   {
Player p = e.getPlayer();
float speed = p.getWalkSpeed();
Collection<PotionEffect> effects = p.getActivePotionEffects();
if (!effects.contains(PotionEffectType.SPEED) || speed < 0.2){

}
	

/*    */   }



}


//... display name here





/*    */ 


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\AntiCheat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */
