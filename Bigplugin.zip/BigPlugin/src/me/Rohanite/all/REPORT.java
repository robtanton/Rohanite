/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ 
/*    */ public class REPORT implements org.bukkit.command.CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public REPORT(Main plugin)
/*    */   {
/* 13 */     this.pl = plugin;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, org.bukkit.command.Command command, String label, String[] args)
/*    */   {
/* 18 */     if (args.length == 1) {
/* 19 */       String reportedname = args[0];
/* 20 */       this.pl.getConfig().set("Report List", this.pl.getConfig().get("Report List") + ", " + reportedname);
/* 21 */       this.pl.saveConfig();
/* 22 */       sender.sendMessage(ChatColor.GREEN + "You reported " + reportedname);
/*    */     }
/*    */     else
/*    */     {
/* 26 */       sender.sendMessage(ChatColor.RED + "Not enough arguments!");
/*    */     }
/*    */     
/* 29 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\REPORT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */