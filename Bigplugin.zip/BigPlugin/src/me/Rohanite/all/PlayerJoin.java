/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.attribute.AttributeInstance;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.server.ServerListPingEvent;

import me.Rohanite.all.api.EconManager;
/*    */ 
/*    */ public class PlayerJoin implements org.bukkit.event.Listener
/*    */ {
/*    */   public static String SWM;
/*    */   private Main plugin;
/*    */   
/*    */   public PlayerJoin(Main pl)
/*    */   {
/* 24 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerJoin(PlayerJoinEvent event)
/*    */   {
/* 30 */     String JM = "";
/* 31 */     Player p = event.getPlayer();
if (EconManager.hasAccount(event.getPlayer().getName())) {
    return;
  }
  EconManager.setBalance(event.getPlayer().getName(), 200);
  Player localPlayer1; for (Iterator localIterator = org.bukkit.Bukkit.getOnlinePlayers().iterator(); localIterator.hasNext(); localPlayer1 = (Player)localIterator.next()) {}
/*    */     
/*    */ 
/* 36 */    // AttributeInstance instance = event.getPlayer()
/* 37 */   //    .getAttribute(org.bukkit.attribute.Attribute.GENERIC_ATTACK_SPEED);
/* 38 */    // if (instance != null) {
/* 39 */    //   instance.setBaseValue(1000.0D);
/*    */    // }
/* 41 */     Player player = event.getPlayer();
/* 42 */     net.minecraft.server.v1_10_R1.PacketPlayOutTitle welcometitle = new net.minecraft.server.v1_10_R1.PacketPlayOutTitle(
/* 43 */       net.minecraft.server.v1_10_R1.PacketPlayOutTitle.EnumTitleAction.TITLE, 
/*    */       
/* 45 */       net.minecraft.server.v1_10_R1.IChatBaseComponent.ChatSerializer.a("{\"text\":\"Welcome to PvPMC!\",\"color\":\"green\",\"underlined\":true}"), 
/* 46 */       0, 80, 40);
/* 47 */     net.minecraft.server.v1_10_R1.PacketPlayOutTitle welcomsubtitle = new net.minecraft.server.v1_10_R1.PacketPlayOutTitle(
/* 48 */       net.minecraft.server.v1_10_R1.PacketPlayOutTitle.EnumTitleAction.SUBTITLE, 
/*    */       
/* 50 */       net.minecraft.server.v1_10_R1.IChatBaseComponent.ChatSerializer.a("{\"text\":\"PRIVATE ALPHA STAGES\",\"color\":\"gold\",\"bold\":true,\"underlined\":true}"), 
/* 51 */       0, 80, 40);
/* 52 */     String WM = ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("Welcome Message"));
/* 53 */     ((org.bukkit.craftbukkit.v1_10_R1.entity.CraftPlayer)player).getHandle().playerConnection
/* 54 */       .sendPacket(welcometitle);
/* 55 */     ((org.bukkit.craftbukkit.v1_10_R1.entity.CraftPlayer)player).getHandle().playerConnection
/* 56 */       .sendPacket(welcomsubtitle);
/* 57 */     event.setJoinMessage(JM);
/*    */     
/* 59 */     player.sendMessage(WM);
/*    */     
/* 61 */     SWM = WM;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void MOTD(ServerListPingEvent e) {
/* 66 */     e.setMotd(ChatColor.GREEN + "Welcome to PvPMC!");
/* 67 */     org.bukkit.Server s = this.plugin.getServer();
/* 68 */     int players = e.getNumPlayers();
/* 69 */     e.setMaxPlayers(players + 1);
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\PlayerJoin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */