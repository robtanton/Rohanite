/*     */ package me.Rohanite.all;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
import java.util.Currency;
import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ import me.Rohanite.hub.commands.Hub;
/*     */ import me.Rohanite.hub.commands.Lobby;
/*     */ import me.Rohanite.hub.commands.SetHub;
/*     */ import me.Rohanite.hub.commands.SetLobby;
/*     */ import me.Rohanite.hub.commands.SetSpawn;
/*     */ import me.Rohanite.hub.commands.Spawn;
/*     */ import me.Rohanite.noplacebreak.event.player.Ondestroyblock;
/*     */ import me.Rohanite.noplacebreak.event.player.Onplaceblock;
/*     */ import me.Rohanite.simplecommands.gma;
/*     */ import me.Rohanite.simplecommands.gmc;
/*     */ import me.Rohanite.simplecommands.gms;
/*     */ import me.Rohanite.simplecommands.gmsp;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Difficulty;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.command.PluginCommand;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionAttachment;
/*     */ import org.bukkit.plugin.PluginDescriptionFile;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.plugin.messaging.Messenger;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ import org.json.simple.JSONObject;

import com.turqmelon.MelonEco.utils.AccountManager;





/*     */ 
/*     */ 
/*     */ public class Main
/*     */   extends JavaPlugin
/*     */ {
	HashMap<String, PermissionAttachment> perms = new HashMap<String, PermissionAttachment>();
/*  41 */   Permission playerPermission = new Permission("hp.commands.sethub");
/*  42 */   Permission onDestroy = new Permission("abillities.destroy");
/*  43 */   Permission onPlace = new Permission("abillities.place");
/*  44 */   Permission killserver = new Permission("bp.server.killserver");
/*  45 */   Permission reportlist = new Permission("bp.cheat.reportlist");
/*  46 */   Permission GMCH = new Permission("sc.commands.gmchange");
Permission kittank = new Permission("kpvp.two");
Permission kitthree = new Permission("kpvp.three");
/*  47 */   public String pluginFolder = getDataFolder().getAbsolutePath();
/*     */   
/*  49 */   public static int running = 1;
/*     */   
/*     */   public void onEnable()
/*     */   {
/*  53 */     PluginDescriptionFile pdffile = getDescription();
/*  54 */     PluginManager pm = getServer().getPluginManager();
/*  55 */     pm.addPermission(this.playerPermission);
/*  56 */     Logger logger = getLogger();
/*  57 */     World world = (World)Bukkit.getWorlds().get(0);
/*  58 */     world.setGameRuleValue("doDaylightCycle", "false");
/*  59 */     world.setGameRuleValue("naturalRegeneration", "false");
/*  60 */     world.setGameRuleValue("doMobSpawning", "false");
/*  61 */     world.setDifficulty(Difficulty.PEACEFUL);
/*  62 */     world.setSpawnLocation(-1, 73, -1);

//new EconManager(this);
/*     */ if (!AccountManager.getCurrencies().isEmpty()){ // Make sure the server has a currency
	  com.turqmelon.MelonEco.utils.Currency currency = AccountManager.getDefaultCurrency();

	  System.out.println("Singular Name: " + currency.getSingular());
	  System.out.println("Plural Name: " + currency.getPlural());

	  // Using format() will automatically append the currency name, a symbol prefix (if specified), and make the provided double friendly
	  System.out.println("Default Balance: " + currency.format(currency.getDefaultBalance()));

	}
/*  64 */     Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "gamerule doDaylightCycle false");
/*  65 */     getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
/*  66 */     getCommand("sethub").setExecutor(new SetHub(this));
/*  67 */     getCommand("nick").setExecutor(new nick(this));
/*  68 */     getCommand("hub").setExecutor(new Hub(this));
            //  getCommand("back").setExecutor(new Back());
/*  69 */     getCommand("spawn").setExecutor(new Spawn(this));
/*  70 */     getCommand("setspawn").setExecutor(new SetSpawn(this));
/*  71 */     getCommand("setlobby").setExecutor(new SetLobby(this));
/*  72 */     getCommand("lobby").setExecutor(new Lobby(this));
/*  73 */     getCommand("gmc").setExecutor(new gmc());
/*  74 */     getCommand("gms").setExecutor(new gms());
/*  75 */     getCommand("gma").setExecutor(new gma());
/*  76 */     getCommand("gmsp").setExecutor(new gmsp());
/*  77 */     getCommand("forcestart").setExecutor(new forcestart());
/*  78 */     getCommand("killserver").setExecutor(new killserver(this));
/*  79 */     getCommand("ping").setExecutor(new Ping(this));
/*  80 */     getCommand("report").setExecutor(new REPORT(this));
/*  81 */     getCommand("reportlist").setExecutor(new ReportList(this));
/*  82 */     getCommand("mban").setExecutor(new MBan(this));
/*  83 */     getCommand("owner").setExecutor(new owner(this));
/*  84 */     getCommand("owner2").setExecutor(new owner2(this));
/*  85 */     getCommand("owner3").setExecutor(new owner3(this));
/*  86 */     getCommand("owner4").setExecutor(new owner4(this));
/*  87 */     getCommand("owner5").setExecutor(new owner5(this));
/*  88 */    // getCommand("bal").setExecutor(new bal());
/*  89 */     getCommand("world").setExecutor(new world(this));
//getCommand("econ").setExecutor(new EconCommand());
//SLAPI.loadBalances();


/*     */     
/*     */ 
/*  97 */     Server s = getServer();
/*     */     
/*  99 */     String gamestate = "Not Running";
/* 100 */     boolean running = false;
/* 101 */     logger.info("Running = " + running);
/* 102 */     logger.info("GameState = " + gamestate);
/* 103 */     saveDefaultConfig();
/* 104 */     registerEvents();
/* 105 */     Bukkit.getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable() {
/*     */       public void run() {
/* 107 */         Server s = Main.this.getServer();
/* 108 */         s.broadcastMessage(ChatColor.GOLD + ""+ChatColor.BOLD + "[" + ChatColor.RESET + ChatColor.RED + 
/* 109 */           ChatColor.BOLD + "*" + ChatColor.RESET + ChatColor.GOLD + ChatColor.BOLD + "]" + 
/* 110 */           ChatColor.RESET + ChatColor.GREEN + " Hacked Clients, and use of any unnaproved mods are");
/* 111 */         s.broadcastMessage(ChatColor.RED +"" +ChatColor.BOLD +""+ ChatColor.UNDERLINE + "STRICTLY PROHIBITED!");
/*     */       }
/* 113 */     }, 600L, 1800L);
/* 114 */     Bukkit.getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable() {
/*     */       public void run() {
/* 116 */         Server s = Main.this.getServer();
/* 117 */         s.broadcastMessage(ChatColor.GOLD +""+ ChatColor.BOLD + "[" + ChatColor.RESET + ChatColor.RED + 
/* 118 */           ChatColor.BOLD + "*" + ChatColor.RESET + ChatColor.GOLD + ChatColor.BOLD + "]" + 
/* 119 */           ChatColor.RESET + ChatColor.GREEN + " Find a Rule-Breaker? Report them with" + ChatColor.RESET + 
/* 120 */           " " + ChatColor.RED + "/report");
/*     */       }
/* 122 */     }, 1200L, 1800L);
/* 123 */     Bukkit.getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable() {
/*     */       public void run() {
/* 125 */         Server s = Main.this.getServer();
/* 126 */         s.broadcastMessage(ChatColor.GOLD +""+ ChatColor.BOLD + "[" + ChatColor.RESET + ChatColor.RED + 
/* 127 */           ChatColor.BOLD + "*" + ChatColor.RESET + ChatColor.GOLD + ChatColor.BOLD + "]" + 
/* 128 */           ChatColor.RESET + ChatColor.GREEN + " Please remember that this server is still in");
/* 129 */         s.broadcastMessage(ChatColor.GOLD +""+ ChatColor.BOLD + ChatColor.UNDERLINE + "EARLY PRIVATE ALPHA" + 
/* 130 */           ChatColor.RESET + " " + ChatColor.GREEN + "stages so it does not have many features at all!");
/*     */       }
/* 132 */     }, 1800L, 1800L);
/* 133 */     logger.info("Welcome to Rohanites Big Plugin!");
/*     */   }
/*     */   
/*     */   public void onDisable()
/*     */   {
/* 138 */     PluginDescriptionFile pdffile = getDescription();
//SLAPI.saveBalances();
/* 142 */     Logger logger = Logger.getLogger("Minecraft");
/* 143 */     logger.info("The Big plugin has been disabled!");
/*     */   }
/*     */   
/*     */   public void registerEvents() {
/* 147 */     PluginManager pm = getServer().getPluginManager();
/*     */     
/* 149 */     pm.registerEvents(new Onplaceblock(this), this);
/* 150 */     pm.registerEvents(new Ondestroyblock(this), this);
/*     */     
/* 152 */     pm.registerEvents(new Onfall(this), this);
/* 153 */     pm.registerEvents(new PlayerJoin(this), this);
/* 154 */     pm.registerEvents(new onDeathScreen(this), this);
/* 155 */     pm.registerEvents(new InvClick(this), this);
/* 156 */     pm.registerEvents(new RainEvent(this), this);
/* 157 */     pm.registerEvents(new Onreload(), this);
pm.registerEvents(new AntiCheat(this), this);
pm.registerEvents(new Onchat(this), this);
/*     */   }
/*     */   
/*     */   public void SendToServer(Player p, String server) {
/* 161 */     ByteArrayOutputStream b = new ByteArrayOutputStream();
/* 162 */     DataOutputStream out = new DataOutputStream(b);
/*     */     try {
/* 164 */       out.writeUTF("Connect");
/* 165 */       out.writeUTF(server);
/*     */     } catch (Exception e) {
/* 167 */       e.printStackTrace();
/*     */     }
/* 169 */     p.sendPluginMessage(this, "BungeeCord", b.toByteArray());
/*     */   }
/*     */   
/* 172 */   public void writeJSON(String fileName, String subPath, String object, String value) { JSONObject main = new JSONObject();
/*     */     
/* 174 */     main.put(object, value);
/*     */     try
/*     */     {
/* 177 */       File file = new File(this.pluginFolder + File.separator + subPath + fileName + ".json");
/* 178 */       File filePath = new File(this.pluginFolder + File.separator + subPath);
/* 179 */       filePath.mkdirs();
/* 180 */       if (!file.exists()) {
/* 181 */         file.createNewFile();
/*     */       }
/* 183 */       FileWriter fileWriter = new FileWriter(file);
/* 184 */       fileWriter.write(main.toJSONString());
/* 185 */       fileWriter.flush();
/* 186 */       fileWriter.close();
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */