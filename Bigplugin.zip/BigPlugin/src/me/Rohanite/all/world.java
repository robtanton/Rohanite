/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class world
/*    */   implements CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/* 14 */   public world(Main plugin) { this.pl = plugin; }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
/* 17 */     this.pl.SendToServer((Player)sender, args[0]);
/* 18 */     return false;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\world.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */