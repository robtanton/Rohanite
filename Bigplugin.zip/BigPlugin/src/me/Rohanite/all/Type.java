package me.Rohanite.all;

public enum Type
{
  KICK,  BAN;
}


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\Type.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */