/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class nick implements org.bukkit.command.CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public nick(Main main)
/*    */   {
/* 13 */     this.pl = main;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
/* 17 */     if (!(sender instanceof Player)) {
/* 18 */       sender.sendMessage(ChatColor.RED + "You are not a player so this command will not work");
/*    */     }
/* 20 */     Player p = (Player)sender;
/* 21 */     p.setDisplayName(ChatColor.translateAlternateColorCodes('&', this.pl.getConfig().getString(args[0])));
/* 22 */     p.sendMessage(ChatColor.GREEN + "You are now nicked");
/* 23 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\nick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */