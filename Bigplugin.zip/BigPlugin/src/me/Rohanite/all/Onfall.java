/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Onfall
/*    */   implements Listener
/*    */ {
/*    */   private Main plugin;
/*    */   private Server s;
/*    */   
/*    */   public Onfall(Main pl)
/*    */   {
/* 22 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */ 
/*    */   @EventHandler
/*    */   public void onFall(EntityDamageEvent event)
/*    */   {
/* 29 */     EntityType Entity = event.getEntityType();
/* 30 */     EntityDamageEvent.DamageCause cause = event.getCause();
/* 31 */     if ((Entity == EntityType.PLAYER) && (cause == EntityDamageEvent.DamageCause.FALL))
/*    */     {
/* 33 */       event.setCancelled(true);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\Onfall.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */