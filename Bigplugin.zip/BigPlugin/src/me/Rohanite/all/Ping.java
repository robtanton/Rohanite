/*    */ package me.Rohanite.all;
/*    */ 
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Ping implements org.bukkit.command.CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public Ping(Main plugin)
/*    */   {
/* 12 */     plugin = this.pl;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean onCommand(CommandSender sender, org.bukkit.command.Command cmd, String label, String[] args)
/*    */   {
/* 19 */     if (!(sender instanceof Player)) {
/* 20 */       sender.sendMessage("Your ping is unknown because your a CONSOLE!");
/*    */       
/* 22 */       return false;
/*    */     }
/* 24 */     Player player = (Player)sender;
/* 25 */     int ping = ((org.bukkit.craftbukkit.v1_10_R1.entity.CraftPlayer)player).getHandle().ping;
/* 26 */     player.sendMessage(org.bukkit.ChatColor.GREEN + "Your ping is: " + org.bukkit.ChatColor.AQUA + ping);
/* 27 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\all\Ping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */