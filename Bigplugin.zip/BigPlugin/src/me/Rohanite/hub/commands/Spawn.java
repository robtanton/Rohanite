/*    */ package me.Rohanite.hub.commands;
/*    */ 
/*    */ import me.Rohanite.all.Main;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Spawn implements CommandExecutor
/*    */ {
/*    */   private Main plugin;
/*    */   
/*    */   public Spawn(Main pl)
/*    */   {
/* 16 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*    */   {
/* 24 */     if (!(sender instanceof Player)) {
/* 25 */       sender.sendMessage("Sorry! The console can't teleport to spawn!");
/* 26 */       return false;
/*    */     }
/*    */     
/* 29 */     Player player = (Player)sender;
/* 30 */     player.sendMessage(ChatColor.GOLD + "Going to spawn...");
/* 31 */     player.teleport((org.bukkit.Location)this.plugin.getConfig().get("spawn-coords"));
/* 32 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\hub\commands\Spawn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */