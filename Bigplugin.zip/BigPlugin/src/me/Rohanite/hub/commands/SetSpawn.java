/*    */ package me.Rohanite.hub.commands;
/*    */ 
/*    */ import me.Rohanite.all.Main;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class SetSpawn implements CommandExecutor
/*    */ {
/*    */   public static Location Spawntp;
/*    */   private Main plugin;
/*    */   
/*    */   public SetSpawn(Main pl)
/*    */   {
/* 18 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*    */   {
/* 25 */     if (!(sender instanceof Player)) {
/* 26 */       sender.sendMessage("Sorry! The console can't set spawn!");
/* 27 */       return false;
/*    */     }
/*    */     
/* 30 */     Player player = (Player)sender;
/* 31 */     if (player.hasPermission("hp.commands.sethub")) {
/* 32 */       player.sendMessage(ChatColor.GOLD + "Spawn set!");
/* 33 */       Location spawn = player.getLocation();
/* 34 */       Spawntp = spawn;
/* 35 */       this.plugin.getConfig().set("spawn-coords", spawn);
/* 36 */       this.plugin.saveConfig();
/*    */     } else {
/* 38 */       player.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
/*    */     }
/*    */     
/* 41 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\hub\commands\SetSpawn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */