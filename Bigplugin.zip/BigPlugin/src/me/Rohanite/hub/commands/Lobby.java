/*    */ package me.Rohanite.hub.commands;
/*    */ 
/*    */ import me.Rohanite.all.Main;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Lobby implements CommandExecutor
/*    */ {
/*    */   private Main plugin;
/*    */   
/*    */   public Lobby(Main pl)
/*    */   {
/* 18 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*    */   {
/* 26 */     if (!(sender instanceof Player)) {
/* 27 */       sender.sendMessage("Sorry! The console can't teleport to the lobby!");
/* 28 */       return false;
/*    */     }
/*    */     
/* 31 */     Player player = (Player)sender;
/* 32 */     player.sendMessage(ChatColor.GOLD + "Going to the lobby...");
/* 33 */     player.teleport((Location)this.plugin.getConfig().get("lobby-coords"));
/* 34 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\hub\commands\Lobby.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */