/*    */ package me.Rohanite.hub.commands;
/*    */ 
/*    */ import me.Rohanite.all.Main;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Hub implements CommandExecutor
/*    */ {
/*    */   private Main plugin;
/*    */   
/*    */   public Hub(Main pl)
/*    */   {
/* 18 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*    */   {
/* 25 */     if (!(sender instanceof Player)) {
/* 26 */       sender.sendMessage("Sorry! The console can't teleport to the hub!");
/* 27 */       return false;
/*    */     }
/*    */     
/* 30 */     Player player = (Player)sender;
/* 31 */     player.sendMessage(ChatColor.GOLD + "Going to the hub...");
/* 32 */     player.teleport((Location)this.plugin.getConfig().get("hub-coords"));
/* 33 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\hub\commands\Hub.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */