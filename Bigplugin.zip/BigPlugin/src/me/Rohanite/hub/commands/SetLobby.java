/*    */ package me.Rohanite.hub.commands;
/*    */ 
/*    */ import me.Rohanite.all.Main;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetLobby
/*    */   implements CommandExecutor
/*    */ {
/*    */   public static Location Lobbytp;
/*    */   private Main plugin;
/*    */   
/*    */   public SetLobby(Main pl)
/*    */   {
/* 22 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*    */   {
/* 27 */     Player player = (Player)sender;
/*    */     
/* 29 */     if (!(sender instanceof Player)) {
/* 30 */       sender.sendMessage("Sorry! The console can't set the lobby!");
/* 31 */       return false;
/*    */     }
/*    */     
/* 34 */     if (player.hasPermission("hp.commands.sethub"))
/*    */     {
/*    */ 
/* 37 */       player.sendMessage(ChatColor.GOLD + "Lobby set!");
/* 38 */       Location lobby = player.getLocation();
/* 39 */       Lobbytp = lobby;
/* 40 */       this.plugin.getConfig().set("lobby-coords", lobby);
/* 41 */       this.plugin.saveConfig();
/*    */     }
/*    */     else {
/* 44 */       player.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
/*    */     }
/*    */     
/* 47 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\hub\commands\SetLobby.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */