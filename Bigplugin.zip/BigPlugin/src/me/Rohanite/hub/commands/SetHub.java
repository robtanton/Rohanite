/*    */ package me.Rohanite.hub.commands;
/*    */ 
/*    */ import me.Rohanite.all.Main;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetHub
/*    */   implements CommandExecutor
/*    */ {
/*    */   public static String coords;
/*    */   private Main plugin;
/*    */   public static Location hubtp;
/*    */   
/*    */   public SetHub(Main pl)
/*    */   {
/* 29 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
/*    */   {
/* 35 */     if (!(sender instanceof Player)) {
/* 36 */       sender.sendMessage("Sorry! The console can't set the hub!");
/* 37 */       return false;
/*    */     }
/*    */     
/* 40 */     Player player = (Player)sender;
/*    */     
/* 42 */     if (player.hasPermission("hp.commands.sethub")) {
/* 43 */       player.sendMessage(ChatColor.GOLD + "Hub set!");
/* 44 */       Location hub = player.getLocation();
/* 45 */       this.plugin.getConfig().set("hub-coords", hub);
/* 46 */       this.plugin.saveConfig();
/*    */     }
/*    */     else {
/* 49 */       player.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
/*    */     }
/* 51 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\hub\commands\SetHub.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */