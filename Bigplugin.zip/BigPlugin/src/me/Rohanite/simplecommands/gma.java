/*    */ package me.Rohanite.simplecommands;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class gma
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
/*    */   {
/* 15 */     if (!(sender instanceof Player)) {
/* 16 */       return false;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 21 */     Player player = (Player)sender;
/* 22 */     if (player.hasPermission("sc.commands.gmchange"))
/*    */     {
/*    */ 
/*    */ 
/* 26 */       player.setGameMode(GameMode.ADVENTURE);
/* 27 */       player.sendMessage(ChatColor.GOLD + "Your gamemode has been changed to adventure mode!");
/*    */     }
/*    */     else {
/* 30 */       player.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
/*    */     }
/* 32 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\simplecommands\gma.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */