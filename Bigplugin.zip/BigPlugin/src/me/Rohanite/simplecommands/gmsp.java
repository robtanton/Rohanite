/*    */ package me.Rohanite.simplecommands;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class gmsp implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
/*    */   {
/* 14 */     if (!(sender instanceof Player)) {
/* 15 */       return false;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 20 */     Player player = (Player)sender;
/* 21 */     if (player.hasPermission("sc.commands.gmchange"))
/*    */     {
/* 23 */       player.setGameMode(GameMode.SPECTATOR);
/* 24 */       player.sendMessage(ChatColor.GOLD + "Your gamemode has been changed to spectator mode!");
/*    */     } else {
/* 26 */       player.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
/*    */     }
/* 28 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\simplecommands\gmsp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */