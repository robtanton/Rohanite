/*    */ package me.Rohanite.simplecommands;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class gms
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
/*    */   {
/* 16 */     if (!(sender instanceof Player)) {
/* 17 */       return false;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 22 */     Player player = (Player)sender;
/* 23 */     if (player.hasPermission("sc.commands.gmchange")) {
/* 24 */       player.setGameMode(GameMode.SURVIVAL);
/* 25 */       player.sendMessage(ChatColor.GOLD + "Your gamemode has been changed to survival mode!");
/*    */     } else {
/* 27 */       player.sendMessage(ChatColor.RED + "You do not have permission to do this command!");
/*    */     }
/* 29 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\simplecommands\gms.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */