/*    */ package me.Rohanite.noplacebreak.event.player;
/*    */ 
/*    */ import me.Rohanite.all.Main;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.block.BlockPlaceEvent;
/*    */ 
/*    */ public class Onplaceblock implements org.bukkit.event.Listener
/*    */ {
/*    */   private Main plugin;
/*    */   
/*    */   public Onplaceblock(Main pl)
/*    */   {
/* 14 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */   @org.bukkit.event.EventHandler
/*    */   public void onPlace(BlockPlaceEvent event) {
/* 19 */     if (!event.getPlayer().hasPermission("abillites.place")) {
/* 20 */       event.setCancelled(true);
/* 21 */       event.getPlayer().sendMessage(ChatColor.RED + "You do not have permission to do this!");
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\noplacebreak\event\player\Onplaceblock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */