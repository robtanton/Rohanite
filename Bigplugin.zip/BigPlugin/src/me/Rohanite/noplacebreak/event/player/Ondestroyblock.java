/*    */ package me.Rohanite.noplacebreak.event.player;
/*    */ 
/*    */ import me.Rohanite.all.Main;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ 
/*    */ public class Ondestroyblock implements Listener
/*    */ {
/*    */   private Main plugin;
/*    */   
/*    */   public Ondestroyblock(Main pl)
/*    */   {
/* 15 */     this.plugin = pl;
/*    */   }
/*    */   
/*    */   @org.bukkit.event.EventHandler
/*    */   public void onDestroy(BlockBreakEvent event) {
/* 20 */     if (!event.getPlayer().hasPermission("abillites.destroy")) {
/* 21 */       event.setCancelled(true);
/* 22 */       event.getPlayer().sendMessage(ChatColor.RED + "You do not have permission to do this!");
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Documents\Bukkit Server\plugins\BigPlugin.jar!\me\Rohanite\noplacebreak\event\player\Ondestroyblock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */